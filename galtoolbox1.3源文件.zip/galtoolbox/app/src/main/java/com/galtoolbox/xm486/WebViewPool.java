package com.galtoolbox.xm486;

import android.content.Context;
import android.util.Log;
import android.webkit.WebView;
import java.util.LinkedList;
import java.util.Queue;

public class WebViewPool {
    private static final String TAG = "WebViewPool";
    private static final int MAX_POOL_SIZE = 2;
    
    private Queue<WebView> idleWebViewQueue = new LinkedList<>();
    private static WebViewPool instance;
    
    public static WebViewPool getInstance() {
        if (instance == null) {
            instance = new WebViewPool();
        }
        return instance;
    }
    
    public WebView acquireWebView(Context context) {
        WebView webView = idleWebViewQueue.poll();
        if (webView == null) {
            webView = new WebView(context);
            Log.d(TAG, "创建新的WebView");
        } else {
            Log.d(TAG, "复用池中的WebView");
        }
        return webView;
    }
    
    public void releaseWebView(WebView webView) {
        if (webView == null) return;
        
        webView.stopLoading();
        webView.clearHistory();
        webView.loadUrl("about:blank");
        
        if (idleWebViewQueue.size() < MAX_POOL_SIZE) {
            idleWebViewQueue.offer(webView);
        } else {
            webView.destroy();
        }
    }
}
